<?php
namespace Kwpanorama;

defined('_JEXEC') or die;

use Joomla\CMS\Filesystem\Folder;

class KWPFolder extends Folder {
	
}