<?php
namespace Joomla\Component\Kwpanorama\Administrator\Helper;


defined('_JEXEC') or die;

class KwpinputHelper extends  \Joomla\CMS\Input\Input {
	
}
