<?php
namespace Kwpanorama;

defined('_JEXEC') or die;

use Joomla\CMS\Filesystem\Path;


class KWPPath extends Path {
	
}
