<?php
namespace Joomla\Component\Kwpanorama\Administrator\Helper;


defined('_JEXEC') or die;

class KwptextHelper extends   \Joomla\CMS\Language\Text {
	
}
