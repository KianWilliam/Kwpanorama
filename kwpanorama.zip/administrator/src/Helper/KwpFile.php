<?php
namespace Kwpanorama;

defined('_JEXEC') or die;
use Joomla\CMS\Filesystem\File;


class KWPFile extends File {
	
}

